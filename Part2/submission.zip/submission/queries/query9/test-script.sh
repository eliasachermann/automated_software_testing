#!/bin/bash
python3 test-scripts/query9/check_bug_crash.py