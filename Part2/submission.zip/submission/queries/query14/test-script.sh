#!/bin/bash
python3 test-scripts/query14/check_bug_crash.py