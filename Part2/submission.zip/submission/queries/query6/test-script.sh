#!/bin/bash
python3 test-scripts/query6/check_bug_crash.py