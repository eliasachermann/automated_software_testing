#!/bin/bash
python3 test-scripts/query2/check_bug_diff.py