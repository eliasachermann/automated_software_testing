#!/bin/bash
python3 test-scripts/query16/check_bug_crash.py