#!/bin/bash
python3 test-scripts/query20/check_bug_crash.py