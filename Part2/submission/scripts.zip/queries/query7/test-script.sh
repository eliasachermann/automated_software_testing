#!/bin/bash
python3 test-scripts/query7/check_bug_diff.py