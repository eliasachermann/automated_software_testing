#!/bin/bash
python3 test-scripts/query13/check_bug_crash.py