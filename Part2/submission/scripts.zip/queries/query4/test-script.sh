#!/bin/bash
python3 test-scripts/query4/check_bug_diff.py