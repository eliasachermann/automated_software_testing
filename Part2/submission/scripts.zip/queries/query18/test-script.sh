#!/bin/bash
python3 test-scripts/query18/check_bug_crash.py