#!/bin/bash
python3 test-scripts/query11/check_bug_diff.py