#!/bin/bash
python3 test-scripts/query10/check_bug_diff.py