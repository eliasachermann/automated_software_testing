Expected result:
1
1
0

Actual result:
1
0