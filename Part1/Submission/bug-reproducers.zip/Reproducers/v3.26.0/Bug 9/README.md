Expected result:

Actual result:
Error: near line 2: no such column: c_jx413v9W

