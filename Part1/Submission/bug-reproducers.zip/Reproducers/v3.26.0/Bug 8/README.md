Expected result:
uR2crVmmEQa_7490|1|text|[3,4,5]|2|1.0|[1,1]|{"VfO1akwEhn_7490":"text","uR2crVmmEQa_7490":"text"}
VfO1akwEhn_7490|1|text|[3,4,5]|2|1.0|[1,1]|{"VfO1akwEhn_7490":"text","uR2crVmmEQa_7490":"text"}


Actual result:
VfO1akwEhn_7490|1|text|[3,4,5]|2|1.0|[1,1]|{"VfO1akwEhn_7490":"text","uR2crVmmEQa_7490":"text"}
uR2crVmmEQa_7490|1|text|[3,4,5]|2|1.0|[1,1]|{"VfO1akwEhn_7490":"text","uR2crVmmEQa_7490":"text"}

