Expected result:
Runtime error: NOT NULL constraint failed: t_N96.c_HoR4r6

Actual result:
1