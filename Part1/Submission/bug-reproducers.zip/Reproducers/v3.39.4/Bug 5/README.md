Expected result:
904113.32505|11||


Actual result:
904113.32505|17||

