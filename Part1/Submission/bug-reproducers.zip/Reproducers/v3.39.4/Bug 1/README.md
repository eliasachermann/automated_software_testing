Expected result:
|0
|0
|0

Actual result:
|0
0|0
0|0